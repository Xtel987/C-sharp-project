﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace IceCreamShopFinal_Nizhnyk
{
    public partial class Form1 : Form
    {
        // declare a customer DataList that will hold customer information 
        List<Customer> customerDataList = new List<Customer>();
        int CustFound = 0;
        bool custFN = false;
        bool custLN = false;
        public string GetID;
        public int currentID;
        public int newID;
        public int custID;
        // another list to store ID numbers
        List<string> ViewCO = new List<string>();
        // Form1 variables
        const string FILENAME = "Order.txt";
        int numbOrder = 0;
        // read from the array of orders and display in the message box
        public string toDisplay;
        // instantiate Order, Customer, and Cone objects
        Order order = new Order();
        Customer customer = new Customer();
        Cone cone = new Cone();
        // Form1 constructor
        public Form1()
        {
            InitializeComponent();
            // gray out order text boxes and buttons before customer 
            // enters personal information 
            btnPlaceOrder.Enabled = false;
            btnAddToOrder.Enabled = false;
            btnCancelOrder.Enabled = false;
            listBoxIceCreamYogurt.Enabled = false;
            listBoxFlavor.Enabled = false;
            listBoxTypeOfCone.Enabled = false;
            comboBoxScoops.Enabled = false;
            // diable customer information boxes and a button
            btnEnterACustomer.Enabled = false;
            textBoxFirstName.Enabled = false;
            textBoxLastName.Enabled = false;
            maskedTextBoxIDNumber.Enabled = true;
            // check the radio button
            radioButtonExistingCustomer.Checked = true;
        }
        // Form1 method
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        // enter a customer button method
        private void btnEnterACustomer_Click(object sender, EventArgs e)
        {
            // using FileStream in case there is no text file in the folder
            using (FileStream inFile = new FileStream(FILENAME, FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite))
            {
            }
            // when the radio button exist checkbox is activated
            if (radioButtonExistingCustomer.Checked == true)
            {
                // assign FirstNText to have the first name text from the text box
                string FirstNText = textBoxFirstName.Text;
                // set the current number of orders to 0
                numbOrder = 0;
                // clear the array
                Array.Clear(order.Cones, 0, order.Cones.Length);
                // reset Order class int z
                order.z = 0;
                // reset the index
                labelNumberOfOrders.Text = " " + 0;
                // clear the list box
                listBoxViewOrders.DataSource = null;
                // call method to look for existing customer
                ExistingCustomer();
                // prompt user if ID is not found in the file
                if (CustFound != 1)
                {
                    MessageBox.Show("ID number was not found. Try again, or become a new customer.", "Not Found");
                    // clear the masked text box so that customer could try again 
                    maskedTextBoxIDNumber.Clear();
                }
                // let the user purchase items if the account is found
                else
                {
                    customer.CustomerID = Convert.ToInt32(maskedTextBoxIDNumber.Text);
                    // disable radio buttons
                    radioButtonExistingCustomer.Enabled = false;
                    radioButtonNewCustomer.Enabled = false;
                    // enable order text boxes and buttons and 
                    btnPlaceOrder.Enabled = true;
                    btnAddToOrder.Enabled = true;
                    btnCancelOrder.Enabled = true;
                    listBoxIceCreamYogurt.Enabled = true;
                    listBoxFlavor.Enabled = true;
                    listBoxTypeOfCone.Enabled = true;
                    comboBoxScoops.Enabled = true;
                    // diable customer information boxes and a button
                    btnEnterACustomer.Enabled = false;
                    textBoxFirstName.Enabled = false;
                    textBoxLastName.Enabled = false;
                    maskedTextBoxIDNumber.Enabled = false;
                    //pre select order items
                    listBoxIceCreamYogurt.SelectedIndex = listBoxIceCreamYogurt.FindString("Ice Cream");
                    listBoxFlavor.SelectedIndex = listBoxFlavor.FindString("Chocolate");
                    comboBoxScoops.SelectedIndex = comboBoxScoops.FindString("1");
                    listBoxTypeOfCone.SelectedIndex = listBoxTypeOfCone.FindString("Waffle Cone");
                }
            }
            // if the radio button new customer is selected 
            else
                if (radioButtonNewCustomer.Checked == true)
                {
                    string FirstNText = textBoxFirstName.Text;
                    // set the current number of orders to 0
                    numbOrder = 0;
                    // clear the array
                    Array.Clear(order.Cones, 0, order.Cones.Length);
                    // reset Order class int z
                    order.z = 0;
                    // reset the index
                    labelNumberOfOrders.Text = " " + 0;
                    // clear the list box
                    listBoxViewOrders.DataSource = null;
                    // call ReadFromFile method
                    ReadFromFile();
                    // ask for customer information
                    customer.FirstName = textBoxFirstName.Text;
                    customer.LastName = textBoxLastName.Text;
                    // assign the calue of currentID to the CustomerID 
                    customer.CustomerID = currentID;
                    // display a message
                    MessageBox.Show(customer.CustomerID + " " + customer.FirstName + " " + customer.LastName, "Data");
                    // assign new ID value to labelNewID
                    labelNewID.Text = Convert.ToString(newID);
                    labelNewID.Text = labelNumberOfOrders.Text = " " + 0;
                    // disable masked text box
                    maskedTextBoxIDNumber.Enabled = false;
                    // call a method that will write to file
                    WriteToFile();
                    // disable both of the radio buttons
                    radioButtonNewCustomer.Enabled = false;
                    radioButtonExistingCustomer.Enabled = false;
                    // enable order text boxes and buttons 
                    btnPlaceOrder.Enabled = true;
                    btnAddToOrder.Enabled = true;
                    btnCancelOrder.Enabled = true;
                    listBoxIceCreamYogurt.Enabled = true;
                    listBoxFlavor.Enabled = true;
                    listBoxTypeOfCone.Enabled = true;
                    comboBoxScoops.Enabled = true;
                    // diable customer information boxes and a button
                    btnEnterACustomer.Enabled = false;
                    textBoxFirstName.Enabled = false;
                    textBoxLastName.Enabled = false;
                    maskedTextBoxIDNumber.Enabled = false;
                    //pre select order items
                    listBoxIceCreamYogurt.SelectedIndex = listBoxIceCreamYogurt.FindString("Ice Cream");
                    listBoxFlavor.SelectedIndex = listBoxFlavor.FindString("Chocolate");
                    comboBoxScoops.SelectedIndex = comboBoxScoops.FindString("1");
                    listBoxTypeOfCone.SelectedIndex = listBoxTypeOfCone.FindString("Waffle Cone");
                }
            // clear the ViewCO list
            ViewCO.Clear();
            // assign text to the new ID lable to display the new customer ID
            labelNewID.Text = Convert.ToString(customer.CustomerID);
            // set the current ID to 0
            currentID = 0;
        }
        // exit btn event
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit(); // exit the application
        }
        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            //labelNewID.Text = maskedTextBoxIDNumber.Text;
            // gray out order text boxes and buttons before customer 
            // enters personal information 
            btnPlaceOrder.Enabled = false;
            btnAddToOrder.Enabled = false;
            btnCancelOrder.Enabled = false;
            listBoxIceCreamYogurt.Enabled = false;
            listBoxFlavor.Enabled = false;
            listBoxTypeOfCone.Enabled = false;
            comboBoxScoops.Enabled = false;
            // display a message box with order information
            // add all the orders into one string
            string outputAr = string.Empty;
            foreach (var item in order.Cones)
            {
                outputAr += item + '\n';
            }
            // display the users, name and order information
            MessageBox.Show("First name: " + textBoxFirstName.Text + " Last name: " +
                textBoxLastName.Text + " ID: " + customer.CustomerID + Environment.NewLine +
                outputAr, "Your Order");
            // activate customer button and text boxes for the new entry
            btnEnterACustomer.Enabled = true;
            textBoxFirstName.Enabled = true;
            textBoxLastName.Enabled = true;
            maskedTextBoxIDNumber.Enabled = true;
            // display in the listbox each record splitting out the fields and eliminating the comma delimiters
            ViewCO.Add(string.Format("First Name: " + textBoxFirstName.Text.PadRight(10) + " Last Name: " +
                textBoxLastName.Text.PadRight(10) + " ID:   " + customer.CustomerID));
            // add more items to the list ViewCo
            ViewCO.AddRange(order.Cones);
            // clear the current ID number
            // clear the list box
            currentID = 0;
            listBoxViewOrders.DataSource = null;
            listBoxViewOrders.Items.Clear();
            // display the full list in the list box
            listBoxViewOrders.DataSource = ViewCO;
            // clear all the customer information from the text boxes
            textBoxFirstName.Clear();
            textBoxLastName.Clear();
            maskedTextBoxIDNumber.Clear();
            //maskedTextBoxIDNumber.Enabled = false;
            radioButtonExistingCustomer.Checked = true;
            btnEnterACustomer.Enabled = false;
            textBoxFirstName.Enabled = false;
            textBoxLastName.Enabled = false;
            labelNewID.Text = "";
            order.totalCost = 0;
            radioButtonExistingCustomer.Enabled = true;
            radioButtonNewCustomer.Enabled = true;

        }
        private void btnAddToOrder_Click(object sender, EventArgs e)
        {
            //labelNewID.Text = maskedTextBoxIDNumber.Text;
            // assign items selected to the class variables on Order class 
            order.IceCreamOrYogurt = Convert.ToString(listBoxIceCreamYogurt.SelectedItem);
            order.Flavor = Convert.ToString(listBoxFlavor.SelectedItem);
            order.NumberOfScoops = Convert.ToInt32(comboBoxScoops.SelectedItem);
            order.TypeOfCone = Convert.ToString(listBoxTypeOfCone.SelectedItem);
            // add one to the index
            labelNumberOfOrders.Text = " " + ++numbOrder;
            // call FillArray method to add one order to the array
            order.Cost();
            order.FillArray();
            // prevent a user from ordering more than 10 orders
            if (numbOrder >= 10)
            {
                MessageBox.Show("You have reached your maximum number of orders (10).", "Order Limit");
                string outputAr = string.Empty;
                foreach (var item in order.Cones)
                {
                    outputAr += item + '\n';
                }
                // gray out order text boxes and buttons before customer 
                // enters personal information 
                btnPlaceOrder.Enabled = false;
                btnAddToOrder.Enabled = false;
                btnCancelOrder.Enabled = false;
                listBoxIceCreamYogurt.Enabled = false;
                listBoxFlavor.Enabled = false;
                listBoxTypeOfCone.Enabled = false;
                comboBoxScoops.Enabled = false;
                // display the users, name and order information
                MessageBox.Show("First name: " + textBoxFirstName.Text + ", Last name: " +
                    textBoxLastName.Text + ", ID: " + customer.CustomerID + Environment.NewLine +
                    outputAr, "Your Order");
                // unselect list box items after they have been added to the order
                listBoxIceCreamYogurt.ClearSelected();
                listBoxFlavor.ClearSelected();
                listBoxTypeOfCone.ClearSelected();
                comboBoxScoops.SelectedIndex = -1;
                // display in the listbox each record splitting out the fields and eliminating the comma delimiters
                ViewCO.Add(string.Format("First Name: " + textBoxFirstName.Text.PadRight(10) + " Last Name: " +
                    textBoxLastName.Text.PadRight(10) + " ID:   " + customer.CustomerID));
                // add more items to the list ViewCo
                ViewCO.AddRange(order.Cones);
                // clear the list box
                listBoxViewOrders.Items.Clear();
                // display the full list in the list box
                listBoxViewOrders.DataSource = ViewCO;
                // clear the customer entry text boxes
                textBoxFirstName.Clear();
                textBoxLastName.Clear();
                maskedTextBoxIDNumber.Clear();
                // enable new customer entry 
                btnEnterACustomer.Enabled = false;
                textBoxFirstName.Enabled = false;
                textBoxLastName.Enabled = false;
                //maskedTextBoxIDNumber.Enabled = true;
                radioButtonExistingCustomer.Checked = true;
                labelNewID.Text = "";
                order.totalCost = 0;
                maskedTextBoxIDNumber.Enabled = true;
                radioButtonExistingCustomer.Enabled = true;
                radioButtonNewCustomer.Enabled = true;
            }
            // unselect list box items after they have been added to the order
            listBoxIceCreamYogurt.ClearSelected();
            listBoxFlavor.ClearSelected();
            listBoxTypeOfCone.ClearSelected();
            comboBoxScoops.SelectedIndex = -1;
            //pre select order items
            listBoxIceCreamYogurt.SelectedIndex = listBoxIceCreamYogurt.FindString("Ice Cream");
            listBoxFlavor.SelectedIndex = listBoxFlavor.FindString("Chocolate");
            comboBoxScoops.SelectedIndex = comboBoxScoops.FindString("1");
            listBoxTypeOfCone.SelectedIndex = listBoxTypeOfCone.FindString("Waffle Cone");
        }
        // call the exit method from the first page exit btn to exit the aplication
        private void btnViewOrdersExit_Click(object sender, EventArgs e)
        {
            btnExit_Click(sender, e);
        }
        // cancel order btn event
        private void btnCancelOrder_Click(object sender, EventArgs e)
        {
            // set the current number of orders to 0
            numbOrder = 0;
            // clear the array
            Array.Clear(order.Cones, 0, order.Cones.Length);
            // reset Order class int z
            order.z = 0;
            // reset the index
            labelNumberOfOrders.Text = " " + 0;
            //reset running total cost
            order.totalCost = 0;
            // prompt user
            MessageBox.Show("Your order has been cancelled.", "Order Cancelled.");
        }
        // view order history from the text file
        private void btnViewOrderHistory_Click(object sender, EventArgs e)
        {
            listBoxViewOrders.DataSource = null;
            listBoxViewOrders.Items.Clear();
            // make a new list called ItemList
            List<string> ItemList = new List<string>();
            using (StreamReader reader = new StreamReader(FILENAME))
            {
                string textLine;
                while ((textLine = reader.ReadLine()) != null)
                {
                    ItemList.Add(textLine);
                    listBoxViewOrders.Items.Add(textLine);
                }
            }
        }
        // view current order from the list
        private void btnViewCurrentOrder_Click(object sender, EventArgs e)
        {
            // clear the list box
            listBoxViewOrders.DataSource = null;
            //listBoxViewOrders.DataSource = order.Cones;
            listBoxViewOrders.DataSource = ViewCO;
        }
        // even method for every time the radio button is selected
        private void radioButtonExistingCustomer_CheckedChanged(object sender, EventArgs e)
        {
            // clear out the text boxes 
            textBoxFirstName.Clear();
            textBoxLastName.Clear();
            //if the button is selected
            if (radioButtonExistingCustomer.Checked == true)
            {
                radioButtonNewCustomer.Checked = false;
            }
            // disable text boxes and enable the masked text box
            btnEnterACustomer.Enabled = false;
            textBoxFirstName.Enabled = false;
            textBoxLastName.Enabled = false;
            maskedTextBoxIDNumber.Enabled = true;
        }
        // is the new customer radio button is selected
        private void radioButtonNewCustomer_CheckedChanged(object sender, EventArgs e)
        {
            // clear the text in the masked text box
            maskedTextBoxIDNumber.Clear();
            // diable customer information boxes and a button
            btnEnterACustomer.Enabled = true;
            textBoxFirstName.Enabled = true;
            textBoxLastName.Enabled = true;
            maskedTextBoxIDNumber.Enabled = false;
            btnEnterACustomer.Enabled = false;
            // if the existing customer button is not selected
            if (radioButtonExistingCustomer.Checked == false)
            {
                radioButtonNewCustomer.Checked = true;
            }
        }
        private void maskedTextBoxIDNumber_TextChanged(object sender, EventArgs e)
        {
            // disable the enter customer button if there is nothing in the ID text box
            if (string.IsNullOrWhiteSpace(maskedTextBoxIDNumber.Text))
            {
                btnEnterACustomer.Enabled = false;
            }
            else
            {
                // re-enable the button
                btnEnterACustomer.Enabled = true;
            }
        }
        // make sure there is text in the first name text box
        private void textBoxFirstName_TextChanged(object sender, EventArgs e)
        {
            // disable the enter customer button if there is nothing in the ID text box
            if (string.IsNullOrWhiteSpace(textBoxFirstName.Text))
            {
                btnEnterACustomer.Enabled = false;
                custFN = false;
            }
            else
            {
                // re-enable the button
                custFN = true;
            }
            // call the reenable button method
            ReenableBTN();
        }
        private void textBoxLastName_TextChanged(object sender, EventArgs e)
        {
            // disable the enter customer button if there is nothing in the ID text box
            if (string.IsNullOrWhiteSpace(textBoxLastName.Text))
            {
                btnEnterACustomer.Enabled = false;
                custLN = false;
            }
            else
            {
                // re-enable the button
                custLN = true;
            }
            // call the reenable button method
            ReenableBTN();
        }
        // method that will reenable the customer entry button
        public void ReenableBTN()
        {
            // reenable the button only if first name 
            // and last name text boxes have text in them
            if (custFN == true && custLN == true)
            {
                btnEnterACustomer.Enabled = true;
            }
            else
            {
                btnEnterACustomer.Enabled = false;
            }
        }
        // public method that will look for existing customer ID
        public void ExistingCustomer()
        {
            custID = Convert.ToInt32(maskedTextBoxIDNumber.Text);
            // call read from file method
            ReadFromFile();
            // foreach loop that will look for the same customer ID in the list
            foreach (Customer customer in customerDataList)
            {
                // when the match is found
                if (custID == customer.CustomerID)
                {
                    CustFound = 1;
                    textBoxFirstName.Text = customer.FirstName;
                    textBoxLastName.Text = customer.LastName;
                    maskedTextBoxIDNumber.Text = Convert.ToString(customer.CustomerID);
                }
            }
            // when there is no match
            if (CustFound != 1)
            {
                // set customer found btn to 0
                CustFound = 0;
                MessageBox.Show("Entered ID was not found.", "Not Found");
            }
        }
        // public method that will read from file
        public void ReadFromFile()
        {
            string line;
            // use streamreader to read from file
            using (StreamReader reader = new StreamReader(FILENAME))
            {
                while (reader.Peek() >= 0)
                {
                    line = reader.ReadLine();
                    string[] split = line.Split(",".ToArray());
                    customerDataList.Add(new Customer(int.Parse(split[0]), split[1], split[2]));
                    currentID = (customerDataList.Last<Customer>().CustomerID + 1);
                }
            }
        }
        // method that writes to file
        public void WriteToFile()
        {
            using (FileStream outFile = new FileStream(FILENAME, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
            {
                using (StreamWriter writer = new StreamWriter(outFile))
                {
                    Customer Newcustomer = new Customer(currentID, textBoxFirstName.Text, textBoxLastName.Text);
                    // write the data to file
                    writer.WriteLine(Newcustomer.ToString());
                    // display a messagebox that displays what was written to the file
                    MessageBox.Show("Wrote " + customer.ToString() + " to file.", "File written");
                    //currentID = 0;
                }
            }
        }
    }
}
