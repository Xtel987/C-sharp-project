﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IceCreamShopFinal_Nizhnyk
{
    class Customer
    {
        // declare the following class variables to store customer information
        public string firstName;
        public string lastName;
        public int customerID;
        // Customer constructor
        public Customer()
        {
        }
        // constructor with parameters
        public Customer(int customerID, string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.customerID = customerID;
        }
        // accessors for each of the declared class variables
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        public int CustomerID
        {
            get { return customerID; }
            set { customerID = value; }
        }
        // override the class ToString method to return a string in the following format
        public new string ToString()
        {
            return (CustomerID + "," + FirstName + "," + LastName);
        }
    }
}
