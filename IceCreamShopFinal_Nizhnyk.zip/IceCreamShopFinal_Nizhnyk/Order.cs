﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IceCreamShopFinal_Nizhnyk
{
    class Order : Cone
    {
        // class variables for z, order cost, and total cost 
        public int z = 0;
        public double orderCost = 0.00;
        public double totalCost = 0.00;
        // Order class constructor
        public Order()
        {
        }
        // declare the following class variables
        public string[] Cones = new string[10];
        // override ToString method
        public override string ToString()
        {
            return (IceCreamOrYogurt + ',' + Flavor + ',' + NumberOfScoops +
                ',' + TypeOfCone + ",   number of orders: " + z + ' ' + totalCost);
        }
        // Cost method that calculates total order cost
        public void Cost()
        {
            // calculate the orderCost
            orderCost = (NumberOfScoops * costPerScoop) + (costPerCone);
            // calculate the total cost of all of the orders
            totalCost += orderCost;
        }
        // create a method to fill array with order information
        public void FillArray()
        {
            if (z <= Cones.Length)
            {
                Cones[z] = (IceCreamOrYogurt + ',' + Flavor + ',' + NumberOfScoops +
                ',' + TypeOfCone + ",   number of orders: " + (z += 1) + ", total running cost: " + totalCost.ToString("C"));
            }
        }
    }
}
