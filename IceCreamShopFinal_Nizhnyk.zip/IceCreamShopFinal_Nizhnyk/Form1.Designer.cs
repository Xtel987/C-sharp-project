﻿namespace IceCreamShopFinal_Nizhnyk
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageOrder = new System.Windows.Forms.TabPage();
            this.labelNewID = new System.Windows.Forms.Label();
            this.radioButtonNewCustomer = new System.Windows.Forms.RadioButton();
            this.radioButtonExistingCustomer = new System.Windows.Forms.RadioButton();
            this.comboBoxScoops = new System.Windows.Forms.ComboBox();
            this.maskedTextBoxIDNumber = new System.Windows.Forms.MaskedTextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.listBoxIceCreamYogurt = new System.Windows.Forms.ListBox();
            this.btnCancelOrder = new System.Windows.Forms.Button();
            this.btnPlaceOrder = new System.Windows.Forms.Button();
            this.btnAddToOrder = new System.Windows.Forms.Button();
            this.labelNumberOfOrders = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.listBoxTypeOfCone = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.listBoxFlavor = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnEnterACustomer = new System.Windows.Forms.Button();
            this.textBoxLastName = new System.Windows.Forms.TextBox();
            this.textBoxFirstName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPageViewOrders = new System.Windows.Forms.TabPage();
            this.btnViewOrdersExit = new System.Windows.Forms.Button();
            this.btnViewOrderHistory = new System.Windows.Forms.Button();
            this.listBoxViewOrders = new System.Windows.Forms.ListBox();
            this.btnViewCurrentOrder = new System.Windows.Forms.Button();
            this.labelScoopPrice = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPageOrder.SuspendLayout();
            this.tabPageViewOrders.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageOrder);
            this.tabControl1.Controls.Add(this.tabPageViewOrders);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(1, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(620, 480);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPageOrder
            // 
            this.tabPageOrder.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tabPageOrder.Controls.Add(this.labelScoopPrice);
            this.tabPageOrder.Controls.Add(this.labelNewID);
            this.tabPageOrder.Controls.Add(this.radioButtonNewCustomer);
            this.tabPageOrder.Controls.Add(this.radioButtonExistingCustomer);
            this.tabPageOrder.Controls.Add(this.comboBoxScoops);
            this.tabPageOrder.Controls.Add(this.maskedTextBoxIDNumber);
            this.tabPageOrder.Controls.Add(this.btnExit);
            this.tabPageOrder.Controls.Add(this.listBoxIceCreamYogurt);
            this.tabPageOrder.Controls.Add(this.btnCancelOrder);
            this.tabPageOrder.Controls.Add(this.btnPlaceOrder);
            this.tabPageOrder.Controls.Add(this.btnAddToOrder);
            this.tabPageOrder.Controls.Add(this.labelNumberOfOrders);
            this.tabPageOrder.Controls.Add(this.label10);
            this.tabPageOrder.Controls.Add(this.listBoxTypeOfCone);
            this.tabPageOrder.Controls.Add(this.label9);
            this.tabPageOrder.Controls.Add(this.listBoxFlavor);
            this.tabPageOrder.Controls.Add(this.label8);
            this.tabPageOrder.Controls.Add(this.label7);
            this.tabPageOrder.Controls.Add(this.label6);
            this.tabPageOrder.Controls.Add(this.label5);
            this.tabPageOrder.Controls.Add(this.btnEnterACustomer);
            this.tabPageOrder.Controls.Add(this.textBoxLastName);
            this.tabPageOrder.Controls.Add(this.textBoxFirstName);
            this.tabPageOrder.Controls.Add(this.label4);
            this.tabPageOrder.Controls.Add(this.label3);
            this.tabPageOrder.Controls.Add(this.label2);
            this.tabPageOrder.Controls.Add(this.label1);
            this.tabPageOrder.Location = new System.Drawing.Point(4, 27);
            this.tabPageOrder.Name = "tabPageOrder";
            this.tabPageOrder.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageOrder.Size = new System.Drawing.Size(612, 449);
            this.tabPageOrder.TabIndex = 0;
            this.tabPageOrder.Text = "Order";
            // 
            // labelNewID
            // 
            this.labelNewID.AutoSize = true;
            this.labelNewID.Location = new System.Drawing.Point(250, 125);
            this.labelNewID.Name = "labelNewID";
            this.labelNewID.Size = new System.Drawing.Size(0, 18);
            this.labelNewID.TabIndex = 24;
            // 
            // radioButtonNewCustomer
            // 
            this.radioButtonNewCustomer.AutoSize = true;
            this.radioButtonNewCustomer.Location = new System.Drawing.Point(375, 75);
            this.radioButtonNewCustomer.Name = "radioButtonNewCustomer";
            this.radioButtonNewCustomer.Size = new System.Drawing.Size(126, 22);
            this.radioButtonNewCustomer.TabIndex = 23;
            this.radioButtonNewCustomer.TabStop = true;
            this.radioButtonNewCustomer.Text = "New Customer";
            this.radioButtonNewCustomer.UseVisualStyleBackColor = true;
            this.radioButtonNewCustomer.CheckedChanged += new System.EventHandler(this.radioButtonNewCustomer_CheckedChanged);
            // 
            // radioButtonExistingCustomer
            // 
            this.radioButtonExistingCustomer.AutoSize = true;
            this.radioButtonExistingCustomer.Location = new System.Drawing.Point(375, 46);
            this.radioButtonExistingCustomer.Name = "radioButtonExistingCustomer";
            this.radioButtonExistingCustomer.Size = new System.Drawing.Size(147, 22);
            this.radioButtonExistingCustomer.TabIndex = 22;
            this.radioButtonExistingCustomer.TabStop = true;
            this.radioButtonExistingCustomer.Text = "Existing Customer";
            this.radioButtonExistingCustomer.UseVisualStyleBackColor = true;
            this.radioButtonExistingCustomer.CheckedChanged += new System.EventHandler(this.radioButtonExistingCustomer_CheckedChanged);
            // 
            // comboBoxScoops
            // 
            this.comboBoxScoops.FormattingEnabled = true;
            this.comboBoxScoops.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.comboBoxScoops.Location = new System.Drawing.Point(444, 219);
            this.comboBoxScoops.Name = "comboBoxScoops";
            this.comboBoxScoops.Size = new System.Drawing.Size(41, 26);
            this.comboBoxScoops.TabIndex = 21;
            // 
            // maskedTextBoxIDNumber
            // 
            this.maskedTextBoxIDNumber.Location = new System.Drawing.Point(194, 122);
            this.maskedTextBoxIDNumber.Mask = "00";
            this.maskedTextBoxIDNumber.Name = "maskedTextBoxIDNumber";
            this.maskedTextBoxIDNumber.Size = new System.Drawing.Size(40, 24);
            this.maskedTextBoxIDNumber.TabIndex = 3;
            this.maskedTextBoxIDNumber.TextChanged += new System.EventHandler(this.maskedTextBoxIDNumber_TextChanged);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(111, 360);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 55);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // listBoxIceCreamYogurt
            // 
            this.listBoxIceCreamYogurt.FormattingEnabled = true;
            this.listBoxIceCreamYogurt.ItemHeight = 18;
            this.listBoxIceCreamYogurt.Items.AddRange(new object[] {
            "Ice Cream",
            "Yogurt"});
            this.listBoxIceCreamYogurt.Location = new System.Drawing.Point(194, 211);
            this.listBoxIceCreamYogurt.Name = "listBoxIceCreamYogurt";
            this.listBoxIceCreamYogurt.Size = new System.Drawing.Size(85, 40);
            this.listBoxIceCreamYogurt.TabIndex = 5;
            // 
            // btnCancelOrder
            // 
            this.btnCancelOrder.Location = new System.Drawing.Point(30, 360);
            this.btnCancelOrder.Name = "btnCancelOrder";
            this.btnCancelOrder.Size = new System.Drawing.Size(75, 55);
            this.btnCancelOrder.TabIndex = 11;
            this.btnCancelOrder.Text = "Cancel \r\nOrder";
            this.btnCancelOrder.UseVisualStyleBackColor = true;
            this.btnCancelOrder.Click += new System.EventHandler(this.btnCancelOrder_Click);
            // 
            // btnPlaceOrder
            // 
            this.btnPlaceOrder.Location = new System.Drawing.Point(444, 398);
            this.btnPlaceOrder.Name = "btnPlaceOrder";
            this.btnPlaceOrder.Size = new System.Drawing.Size(119, 38);
            this.btnPlaceOrder.TabIndex = 10;
            this.btnPlaceOrder.Text = "Place an Order";
            this.btnPlaceOrder.UseVisualStyleBackColor = true;
            this.btnPlaceOrder.Click += new System.EventHandler(this.btnPlaceOrder_Click);
            // 
            // btnAddToOrder
            // 
            this.btnAddToOrder.Location = new System.Drawing.Point(444, 354);
            this.btnAddToOrder.Name = "btnAddToOrder";
            this.btnAddToOrder.Size = new System.Drawing.Size(119, 38);
            this.btnAddToOrder.TabIndex = 9;
            this.btnAddToOrder.Text = "Add to Order";
            this.btnAddToOrder.UseVisualStyleBackColor = true;
            this.btnAddToOrder.Click += new System.EventHandler(this.btnAddToOrder_Click);
            // 
            // labelNumberOfOrders
            // 
            this.labelNumberOfOrders.AutoSize = true;
            this.labelNumberOfOrders.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumberOfOrders.Location = new System.Drawing.Point(322, 372);
            this.labelNumberOfOrders.Name = "labelNumberOfOrders";
            this.labelNumberOfOrders.Size = new System.Drawing.Size(0, 20);
            this.labelNumberOfOrders.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(198, 372);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 20);
            this.label10.TabIndex = 17;
            this.label10.Text = "Current Orders:\r\n";
            // 
            // listBoxTypeOfCone
            // 
            this.listBoxTypeOfCone.FormattingEnabled = true;
            this.listBoxTypeOfCone.ItemHeight = 18;
            this.listBoxTypeOfCone.Items.AddRange(new object[] {
            "Waffle Cone",
            "Sugar Cone",
            "Pretzel Cone",
            "Gluten Free Cone"});
            this.listBoxTypeOfCone.Location = new System.Drawing.Point(444, 257);
            this.listBoxTypeOfCone.Name = "listBoxTypeOfCone";
            this.listBoxTypeOfCone.Size = new System.Drawing.Size(132, 76);
            this.listBoxTypeOfCone.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(362, 277);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 48);
            this.label9.TabIndex = 15;
            this.label9.Text = "  Type of \r\n     cone\r\nPrice: $0.75";
            // 
            // listBoxFlavor
            // 
            this.listBoxFlavor.FormattingEnabled = true;
            this.listBoxFlavor.ItemHeight = 18;
            this.listBoxFlavor.Items.AddRange(new object[] {
            "Chocolate",
            "Vanilla",
            "Teaberry",
            "Raspberry",
            "Orange"});
            this.listBoxFlavor.Location = new System.Drawing.Point(194, 257);
            this.listBoxFlavor.Name = "listBoxFlavor";
            this.listBoxFlavor.Size = new System.Drawing.Size(120, 94);
            this.listBoxFlavor.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(362, 216);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 32);
            this.label8.TabIndex = 11;
            this.label8.Text = "Number of \r\n    scoops";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(24, 293);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Pick a flavor";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(24, 224);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 16);
            this.label6.TabIndex = 9;
            this.label6.Text = "Choose one";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(190, 172);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(185, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Enter Customer Order";
            // 
            // btnEnterACustomer
            // 
            this.btnEnterACustomer.Location = new System.Drawing.Point(444, 103);
            this.btnEnterACustomer.Name = "btnEnterACustomer";
            this.btnEnterACustomer.Size = new System.Drawing.Size(132, 52);
            this.btnEnterACustomer.TabIndex = 4;
            this.btnEnterACustomer.Text = "Enter a Customer";
            this.btnEnterACustomer.UseVisualStyleBackColor = true;
            this.btnEnterACustomer.Click += new System.EventHandler(this.btnEnterACustomer_Click);
            // 
            // textBoxLastName
            // 
            this.textBoxLastName.Location = new System.Drawing.Point(194, 90);
            this.textBoxLastName.Name = "textBoxLastName";
            this.textBoxLastName.Size = new System.Drawing.Size(143, 24);
            this.textBoxLastName.TabIndex = 2;
            this.textBoxLastName.TextChanged += new System.EventHandler(this.textBoxLastName_TextChanged);
            // 
            // textBoxFirstName
            // 
            this.textBoxFirstName.Location = new System.Drawing.Point(194, 50);
            this.textBoxFirstName.Name = "textBoxFirstName";
            this.textBoxFirstName.Size = new System.Drawing.Size(143, 24);
            this.textBoxFirstName.TabIndex = 1;
            this.textBoxFirstName.TextChanged += new System.EventHandler(this.textBoxFirstName_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "CustomerID Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(190, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Customer Information ";
            // 
            // tabPageViewOrders
            // 
            this.tabPageViewOrders.BackColor = System.Drawing.Color.DarkGreen;
            this.tabPageViewOrders.Controls.Add(this.btnViewOrdersExit);
            this.tabPageViewOrders.Controls.Add(this.btnViewOrderHistory);
            this.tabPageViewOrders.Controls.Add(this.listBoxViewOrders);
            this.tabPageViewOrders.Controls.Add(this.btnViewCurrentOrder);
            this.tabPageViewOrders.Location = new System.Drawing.Point(4, 27);
            this.tabPageViewOrders.Name = "tabPageViewOrders";
            this.tabPageViewOrders.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageViewOrders.Size = new System.Drawing.Size(612, 449);
            this.tabPageViewOrders.TabIndex = 1;
            this.tabPageViewOrders.Text = "ViewOrders";
            // 
            // btnViewOrdersExit
            // 
            this.btnViewOrdersExit.Location = new System.Drawing.Point(414, 378);
            this.btnViewOrdersExit.Name = "btnViewOrdersExit";
            this.btnViewOrdersExit.Size = new System.Drawing.Size(143, 44);
            this.btnViewOrdersExit.TabIndex = 4;
            this.btnViewOrdersExit.Text = "Exit";
            this.btnViewOrdersExit.UseVisualStyleBackColor = true;
            this.btnViewOrdersExit.Click += new System.EventHandler(this.btnViewOrdersExit_Click);
            // 
            // btnViewOrderHistory
            // 
            this.btnViewOrderHistory.Location = new System.Drawing.Point(56, 378);
            this.btnViewOrderHistory.Name = "btnViewOrderHistory";
            this.btnViewOrderHistory.Size = new System.Drawing.Size(136, 45);
            this.btnViewOrderHistory.TabIndex = 2;
            this.btnViewOrderHistory.Text = "View Order History";
            this.btnViewOrderHistory.UseVisualStyleBackColor = true;
            this.btnViewOrderHistory.Click += new System.EventHandler(this.btnViewOrderHistory_Click);
            // 
            // listBoxViewOrders
            // 
            this.listBoxViewOrders.FormattingEnabled = true;
            this.listBoxViewOrders.ItemHeight = 18;
            this.listBoxViewOrders.Location = new System.Drawing.Point(7, 6);
            this.listBoxViewOrders.Name = "listBoxViewOrders";
            this.listBoxViewOrders.Size = new System.Drawing.Size(598, 364);
            this.listBoxViewOrders.TabIndex = 1;
            // 
            // btnViewCurrentOrder
            // 
            this.btnViewCurrentOrder.Location = new System.Drawing.Point(234, 378);
            this.btnViewCurrentOrder.Name = "btnViewCurrentOrder";
            this.btnViewCurrentOrder.Size = new System.Drawing.Size(141, 44);
            this.btnViewCurrentOrder.TabIndex = 3;
            this.btnViewCurrentOrder.Text = "View Current Order";
            this.btnViewCurrentOrder.UseVisualStyleBackColor = true;
            this.btnViewCurrentOrder.Click += new System.EventHandler(this.btnViewCurrentOrder_Click);
            // 
            // labelScoopPrice
            // 
            this.labelScoopPrice.AutoSize = true;
            this.labelScoopPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelScoopPrice.Location = new System.Drawing.Point(509, 222);
            this.labelScoopPrice.Name = "labelScoopPrice";
            this.labelScoopPrice.Size = new System.Drawing.Size(69, 16);
            this.labelScoopPrice.TabIndex = 25;
            this.labelScoopPrice.Text = "Price: 0.50";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 482);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "IceCreamShop";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPageOrder.ResumeLayout(false);
            this.tabPageOrder.PerformLayout();
            this.tabPageViewOrders.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageOrder;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPageViewOrders;
        private System.Windows.Forms.Button btnViewCurrentOrder;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxLastName;
        private System.Windows.Forms.TextBox textBoxFirstName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnEnterACustomer;
        private System.Windows.Forms.ListBox listBoxFlavor;
        private System.Windows.Forms.ListBox listBoxTypeOfCone;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnPlaceOrder;
        private System.Windows.Forms.Button btnAddToOrder;
        private System.Windows.Forms.Label labelNumberOfOrders;
        private System.Windows.Forms.Button btnCancelOrder;
        private System.Windows.Forms.Button btnViewOrderHistory;
        private System.Windows.Forms.ListBox listBoxViewOrders;
        private System.Windows.Forms.Button btnViewOrdersExit;
        private System.Windows.Forms.ListBox listBoxIceCreamYogurt;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxIDNumber;
        private System.Windows.Forms.ComboBox comboBoxScoops;
        private System.Windows.Forms.RadioButton radioButtonNewCustomer;
        private System.Windows.Forms.RadioButton radioButtonExistingCustomer;
        private System.Windows.Forms.Label labelNewID;
        private System.Windows.Forms.Label labelScoopPrice;
    }
}

