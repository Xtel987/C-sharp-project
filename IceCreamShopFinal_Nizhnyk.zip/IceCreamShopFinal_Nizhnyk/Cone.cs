﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IceCreamShopFinal_Nizhnyk
{
    // class file named Cone
    class Cone 
    {
        // Cone constructor
        public Cone()
        {
        }
        // declare the following class variables
        private string iceCreamOrYogurt;
        private string flavor;
        private int numberOfScoops;
        private string typeOfCone;
        public static double costPerScoop = .50;
        public static double costPerCone = .75;
        // accessors for each of the declared class variables
        public string IceCreamOrYogurt
        {
            get { return iceCreamOrYogurt; }
            set { iceCreamOrYogurt = value; }
        }
        public string Flavor
        {
            get { return flavor; }
            set { flavor = value; }
        }
        public int NumberOfScoops
        {
            get { return numberOfScoops; }
            set { numberOfScoops = value; }
        }
        public string TypeOfCone
        {
            get { return typeOfCone; }
            set { typeOfCone = value; }
        }
        // override the class ToString method that returns a string in the following format
        public override string ToString()
        {
            return (IceCreamOrYogurt + ",   " + Flavor + ",   " + NumberOfScoops +
                ",   " + TypeOfCone);
        }
    }
}
